
import { User, TaskStatus, Team, UserRole } from './types';

export const PREDEFINED_TEAMS: Team[] = [
  { id: 'team-sales', name: 'Sales Team' },
  { id: 'team-campaign', name: 'Campaign Manager Team' },
  { id: 'team-design', name: 'Designer Team' },
  { id: 'team-dev', name: 'Website Developer Team' },
  { id: 'team-social', name: 'Social Media Manager Team' },
  { id: 'team-googleads', name: 'Google Ads Manager Team' },
  { id: 'team-metaads', name: 'Meta Ads Manager Team' },
];

export const PREDEFINED_USERS: User[] = [
  // Sales Team
  { id: 'mukesh', name: 'Mukesh', password: 'password123', teamId: 'team-sales', avatarUrl: 'https://picsum.photos/seed/mukesh/100/100', role: 'admin', designation: 'Sales Director' },
  { id: 'komal', name: 'Komal', password: 'password123', teamId: 'team-sales', avatarUrl: 'https://picsum.photos/seed/komal/100/100', role: 'user', designation: 'Sales Team' },
  { id: 'shubham', name: 'Shubham', password: 'password123', teamId: 'team-sales', avatarUrl: 'https://picsum.photos/seed/shubham/100/100', role: 'user', designation: 'Sales Team' },
  { id: 'madhav', name: 'Madhav', password: 'password123', teamId: 'team-sales', avatarUrl: 'https://picsum.photos/seed/madhav/100/100', role: 'user', designation: 'Sales Team' },
  { id: 'satish', name: 'Satish', password: 'password123', teamId: 'team-sales', avatarUrl: 'https://picsum.photos/seed/satish/100/100', role: 'user', designation: 'Sales Team' },

  // Campaign & Ads Teams
  { id: 'ranjit', name: 'Ranjit', password: 'password123', teamId: 'team-campaign', avatarUrl: 'https://picsum.photos/seed/ranjit/100/100', role: 'admin', designation: 'Campaign Manager' },
  { id: 'hitesh', name: 'Hitesh', password: 'password123', teamId: 'team-metaads', avatarUrl: 'https://picsum.photos/seed/hitesh/100/100', role: 'user', designation: 'Meta Ads Specialist'},
  { id: 'lavina', name: 'Lavina', password: 'password123', teamId: 'team-metaads', avatarUrl: 'https://picsum.photos/seed/lavina/100/100', role: 'user', designation: 'Meta Ads Specialist' },
  { id: 'prajakta', name: 'Prajakta', password: 'password123', teamId: 'team-googleads', avatarUrl: 'https://picsum.photos/seed/prajakta/100/100', role: 'user', designation: 'Google Ads Specialist' },
  
  // Social Media Team
  { id: 'rishi', name: 'Rishi', password: 'password123', teamId: 'team-social', avatarUrl: 'https://picsum.photos/seed/rishi/100/100', role: 'user', designation: 'Social Media Manager' },
  { id: 'rishika', name: 'Rishika', password: 'password123', teamId: 'team-social', avatarUrl: 'https://picsum.photos/seed/rishika/100/100', role: 'user', designation: 'Social Media Strategist'},

  // Development Team
  { id: 'saurabh', name: 'Saurabh', password: 'password123', teamId: 'team-dev', avatarUrl: 'https://picsum.photos/seed/saurabh/100/100', role: 'user', designation: 'Senior Developer' },
  { id: 'rohit', name: 'Rohit', password: 'password123', teamId: 'team-dev', avatarUrl: 'https://picsum.photos/seed/rohit/100/100', role: 'user', designation: 'Frontend Developer' },
  { id: 'akshay', name: 'Akshay', password: 'password123', teamId: 'team-dev', avatarUrl: 'https://picsum.photos/seed/akshay/100/100', role: 'user', designation: 'Frontend Developer' },

  // Design Team
  { id: 'rahul', name: 'Rahul', password: 'password123', teamId: 'team-design', avatarUrl: 'https://picsum.photos/seed/rahul/100/100', role: 'user', designation: 'Design Team Lead' },
  { id: 'siddhi', name: 'Siddhi', password: 'password123', teamId: 'team-design', avatarUrl: 'https://picsum.photos/seed/siddhi/100/100', role: 'user', designation: 'Design Team' },
  { id: 'dipti', name: 'Dipti', password: 'password123', teamId: 'team-design', avatarUrl: 'https://picsum.photos/seed/dipti/100/100', role: 'user', designation: 'Design Team' },
  { id: 'neha', name: 'Neha', password: 'password123', teamId: 'team-design', avatarUrl: 'https://picsum.photos/seed/neha/100/100', role: 'user', designation: 'Design Team' },
  { id: 'gopika', name: 'Gopika', password: 'password123', teamId: 'team-design', avatarUrl: 'https://picsum.photos/seed/gopika/100/100', role: 'user', designation: 'Design Team' },
  { id: 'prathamesh', name: 'Prathamesh', password: 'password123', teamId: 'team-design', avatarUrl: 'https://picsum.photos/seed/prathamesh/100/100', role: 'user', designation: 'Design Team' },
];

export const STATUS_OPTIONS: { value: TaskStatus; label: string; color: string; icon?: React.ReactNode }[] = [
  { value: TaskStatus.Pending, label: 'Pending', color: 'bg-yellow-500' },
  { value: TaskStatus.InProgress, label: 'In Progress', color: 'bg-blue-500' },
  { value: TaskStatus.Completed, label: 'Completed', color: 'bg-green-500' },
];