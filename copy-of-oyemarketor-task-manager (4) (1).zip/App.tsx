
import React, { useState, useEffect, useCallback } from 'react';
import { Task, User, Team, TaskStatus, Page, UserRole } from './types';
import { PREDEFINED_USERS, PREDEFINED_TEAMS } from './constants';
import Navbar from './components/Navbar';
import { TaskList } from './components/TaskList';
import { TaskForm } from './components/TaskForm';
import Modal from './components/Modal';
import AdminPage from './pages/AdminPage';
import LoginPage from './pages/LoginPage';
import ProfilePage from './pages/ProfilePage';
import { UserFormData as AdminUserFormData } from './components/admin/UserFormModal';
import { ProfileFormData } from './components/ProfileFormModal';


const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [loggedInUser, setLoggedInUser] = useState<User | null>(null);
  const [loginError, setLoginError] = useState<string | null>(null);

  useEffect(() => {
    let loadedUsers: User[] = PREDEFINED_USERS;
    try {
      const storedUsers = localStorage.getItem('users');
      if (storedUsers) {
        loadedUsers = JSON.parse(storedUsers);
         // Ensure existing users have customAssignmentRules property if missing
        loadedUsers = loadedUsers.map(u => ({ ...u, customAssignmentRules: u.customAssignmentRules || undefined }));
      }
    } catch (error) {
      console.error("Failed to load users from localStorage, using defaults:", error);
      localStorage.removeItem('users'); 
    }
    setUsers(loadedUsers);

    let loadedTeams: Team[] = PREDEFINED_TEAMS;
    try {
      const storedTeams = localStorage.getItem('teams');
      if (storedTeams) {
        loadedTeams = JSON.parse(storedTeams);
      }
    } catch (error) {
      console.error("Failed to load teams from localStorage, using defaults:", error);
      localStorage.removeItem('teams');
    }
    setTeams(loadedTeams);

    try {
      const storedTasks = localStorage.getItem('tasks');
      const adminUser = loadedUsers.find(u => u.role === 'admin');
      const defaultCreatorId = adminUser ? adminUser.id : (loadedUsers.length > 0 ? loadedUsers[0].id : undefined);

      if (storedTasks) {
        setTasks(JSON.parse(storedTasks).map((task: Task) => ({...task, creatorId: task.creatorId || defaultCreatorId })));
      } else {
        const sampleAssignee1 = loadedUsers.find(u => u.teamId === 'team-sales')?.id || (loadedUsers.length > 0 ? loadedUsers[0].id : null);
        const sampleAssignee2 = loadedUsers.find(u => u.teamId === 'team-design')?.id || (loadedUsers.length > 3 ? loadedUsers[Math.min(3, loadedUsers.length -1 )].id : null);
        const initialTasks: Task[] = [
           {
            id: crypto.randomUUID(),
            title: 'Draft Q3 Sales Strategy',
            description: 'Outline key objectives and tactics for the upcoming sales quarter.',
            assigneeId: sampleAssignee1,
            status: TaskStatus.InProgress,
            dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            creatorId: defaultCreatorId,
          },
          {
            id: crypto.randomUUID(),
            title: 'Design New Ad Campaign Mockups',
            description: 'Create visuals for the new social media ad campaign.',
            assigneeId: sampleAssignee2,
            status: TaskStatus.Pending,
            dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            creatorId: defaultCreatorId,
          },
        ];
        setTasks(initialTasks);
      }
    } catch (error) {
      console.error("Failed to load or initialize tasks:", error);
      if (localStorage.getItem('tasks')) { 
        localStorage.removeItem('tasks');
      }
      const usersForSampleFallback = loadedUsers.length > 0 ? loadedUsers : PREDEFINED_USERS;
      const adminUserFallback = usersForSampleFallback.find(u => u.role === 'admin');
      const defaultCreatorIdFallback = adminUserFallback ? adminUserFallback.id : (usersForSampleFallback.length > 0 ? usersForSampleFallback[0].id : undefined);
      const sampleAssignee1Fb = usersForSampleFallback.find(u => u.teamId === 'team-sales')?.id || (usersForSampleFallback.length > 0 ? usersForSampleFallback[0].id : null);
      const sampleAssignee2Fb = usersForSampleFallback.find(u => u.teamId === 'team-design')?.id || (usersForSampleFallback.length > 3 ? usersForSampleFallback[Math.min(3, usersForSampleFallback.length -1)].id : null);
      
      const initialTasksFallback: Task[] = [
         {
            id: crypto.randomUUID(),
            title: 'Draft Q3 Sales Strategy (Fallback)',
            description: 'Outline key objectives and tactics for the upcoming sales quarter.',
            assigneeId: sampleAssignee1Fb,
            status: TaskStatus.InProgress,
            dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            creatorId: defaultCreatorIdFallback,
          },
          {
            id: crypto.randomUUID(),
            title: 'Design New Ad Campaign Mockups (Fallback)',
            description: 'Create visuals for the new social media ad campaign.',
            assigneeId: sampleAssignee2Fb,
            status: TaskStatus.Pending,
            dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            creatorId: defaultCreatorIdFallback,
          },
      ];
      setTasks(initialTasksFallback);
    }
  }, []);


  useEffect(() => {
    if (users.length > 0) { 
        localStorage.setItem('users', JSON.stringify(users));
    }
  }, [users]);

  useEffect(() => {
    if (teams.length > 0) {
        localStorage.setItem('teams', JSON.stringify(teams));
    }
  }, [teams]);
  
  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);


  const handleLogin = useCallback((userIdInput: string, passwordInput: string) => {
    const user = users.find(u => u.id.toLowerCase() === userIdInput.toLowerCase() && u.password === passwordInput);
    if (user) {
      setLoggedInUser(user);
      setCurrentPage('tasks');
      setLoginError(null);
    } else {
      setLoginError('Invalid User ID or Password.');
    }
  }, [users]);

  const handleLogout = useCallback(() => {
    setLoggedInUser(null);
    setCurrentPage('login');
  }, []);
  
  const canCreateNewTasks = useCallback((user: User | null): boolean => {
    if (!user) return false;
    if (user.role === 'admin') return true;
    // User can create tasks if they have custom assignment rules configured
    if (user.role === 'user' && user.customAssignmentRules) return true; 
    return false;
  }, []);

  const handleOpenModal = useCallback((task: Task | null = null) => {
    if (!loggedInUser) return;
    
    if (!task && !canCreateNewTasks(loggedInUser)) {
        alert("You do not have permission to create new tasks.");
        return;
    }
    setEditingTask(task);
    setIsModalOpen(true);
  }, [loggedInUser, canCreateNewTasks]);

  const handleCloseModal = useCallback(() => {
    setIsModalOpen(false);
    setEditingTask(null);
  }, []);
  
  const canAssignTask = useCallback((assigner: User, assigneeToTest: User | undefined | null): boolean => {
    if (!assigneeToTest) return true; // Allowing unassignment or assignment to null

    // Rule 0: Admin can do anything
    if (assigner.role === 'admin') return true;
    
    // Rule 0.5: If assigner is not admin, but trying to assign to themselves, allow it.
    if (assigner.id === assigneeToTest.id) return true;

    // Rule 1: Custom Assignment Rules take precedence for 'user' role
    if (assigner.role === 'user' && assigner.customAssignmentRules && assigner.customAssignmentRules.allowedAssigneeIds) {
        return assigner.customAssignmentRules.allowedAssigneeIds.includes(assigneeToTest.id);
    }
    
    // Default deny for 'user' to assign to others if no custom rules and not self-assigning
    return false; 
  }, []);


  const handleSaveTask = useCallback((taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'creatorId'> | Task) => {
    if (!loggedInUser) return;

    const taskToSave = 'id' in taskData ? taskData : null;

    // Check assignment permission if assignee is being set or changed
    if (taskData.assigneeId || (taskToSave && taskToSave.assigneeId !== taskData.assigneeId)) {
        const assignee = users.find(u => u.id === taskData.assigneeId);
        if (taskData.assigneeId && !canAssignTask(loggedInUser, assignee)) { // only check if assigneeId is not null
            alert("You do not have permission to assign this task to the selected user.");
            return;
        }
    }
    
    if (taskToSave) { // Editing existing task
        const originalTask = tasks.find(t => t.id === taskToSave.id);
        if (!originalTask) return;

        let canEdit = false;
        if (loggedInUser.role === 'admin') {
            canEdit = true;
        } else if (loggedInUser.role === 'user') {
            if (originalTask.assigneeId === loggedInUser.id || originalTask.creatorId === loggedInUser.id) {
                canEdit = true;
            }
        }
        
        if (!canEdit) {
            alert("You do not have permission to edit this task.");
            return;
        }
    } else { // Creating new task
        if (!canCreateNewTasks(loggedInUser)) {
            alert("You do not have permission to create new tasks."); 
            return;
        }
    }

    if (taskToSave) { 
      setTasks(prevTasks =>
        prevTasks.map(task =>
          task.id === taskToSave.id ? { ...task, ...taskData, id: task.id, creatorId: task.creatorId, updatedAt: new Date().toISOString() } : task
        )
      );
    } else { 
      const newTask: Task = {
        ...(taskData as Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'creatorId'>), 
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        creatorId: loggedInUser.id,
      };
      setTasks(prevTasks => [newTask, ...prevTasks]);
    }
    handleCloseModal();
  }, [loggedInUser, users, tasks, handleCloseModal, canAssignTask, canCreateNewTasks]);

  const handleDeleteTask = useCallback((taskId: string) => {
    if (!loggedInUser) return;
    const taskToDelete = tasks.find(t => t.id === taskId);
    if (!taskToDelete) return;

    let canDelete = false;
    if (loggedInUser.role === 'admin') {
      canDelete = true;
    } else if (loggedInUser.role === 'user' && taskToDelete.creatorId === loggedInUser.id) {
      canDelete = true;
    } 
    
    if (!canDelete) {
        alert("You do not have permission to delete this task.");
        return;
    }

    if (window.confirm('Are you sure you want to delete this task?')) {
      setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
    }
  }, [loggedInUser, tasks]);

  const handleUpdateTaskStatus = useCallback((taskId: string, status: TaskStatus) => {
    if (!loggedInUser) return;
    const taskToUpdate = tasks.find(t => t.id === taskId);
    if (!taskToUpdate) return;

    let canUpdate = false;
    if (loggedInUser.role === 'admin') {
        canUpdate = true;
    } else if (loggedInUser.role === 'user') { 
        if (taskToUpdate.assigneeId === loggedInUser.id || taskToUpdate.creatorId === loggedInUser.id) { 
            canUpdate = true;
        }
    }

    if (!canUpdate) {
        alert("You do not have permission to update this task's status.");
        return;
    }

    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === taskId ? { ...task, status, updatedAt: new Date().toISOString() } : task
      )
    );
  }, [loggedInUser, tasks]);

  const handleAddUser = useCallback((userData: AdminUserFormData) => {
    if (!loggedInUser || loggedInUser.role !== 'admin') {
        alert("Only admins can add users.");
        return;
    }
    if (users.find(u => u.id.toLowerCase() === userData.id.toLowerCase())) {
        alert('User ID already exists. Please choose a different ID.');
        return;
    }
    const newUser: User = {
      id: userData.id,
      name: userData.name,
      password: userData.password,
      teamId: userData.teamId,
      role: userData.role,
      designation: userData.designation,
      avatarUrl: userData.avatarUrl || undefined, 
      customAssignmentRules: undefined, // New users start with no custom rules
    };
    setUsers(prevUsers => [...prevUsers, newUser]);
  }, [users, loggedInUser]);
  
  const handleUpdateUser = useCallback((originalUserId: string, updatedUserFromForm: AdminUserFormData) => {
     if (!loggedInUser || loggedInUser.role !== 'admin') {
        alert("Only admins can update users.");
        return;
     }
     const userToUpdate = users.find(u => u.id === originalUserId);
     if(!userToUpdate) {
        console.error("User to update not found with original ID:", originalUserId);
        alert("Error: Could not find the user to update.");
        return;
     }

    const newId = updatedUserFromForm.id;
    if (newId.toLowerCase() !== originalUserId.toLowerCase() && users.some(u => u.id.toLowerCase() === newId.toLowerCase())) {
      alert('The new User ID is already taken. Please choose a different one.');
      return;
    }

    let finalUserData: User = { 
        ...userToUpdate, 
        name: updatedUserFromForm.name,
        teamId: updatedUserFromForm.teamId,
        role: updatedUserFromForm.role,
        designation: updatedUserFromForm.designation,
        id: newId,
        customAssignmentRules: userToUpdate.customAssignmentRules // Preserve existing custom rules
    };
    
    if (updatedUserFromForm.avatarUrl === '') { // Explicitly removed
        finalUserData.avatarUrl = undefined;
    } else if (updatedUserFromForm.avatarUrl) { // New avatar provided or existing one kept if not changed in form
        finalUserData.avatarUrl = updatedUserFromForm.avatarUrl;
    } else { // No change from form, keep original
        finalUserData.avatarUrl = userToUpdate.avatarUrl;
    }

    if (updatedUserFromForm.password) {
        finalUserData.password = updatedUserFromForm.password;
    } else {
        finalUserData.password = userToUpdate.password; 
    }
    
    setUsers(prevUsers => prevUsers.map(user => 
        user.id === originalUserId ? finalUserData : user
    ));

    if (newId.toLowerCase() !== originalUserId.toLowerCase()) {
      setTasks(prevTasks => prevTasks.map(task => {
        let updatedTask = { ...task };
        if (task.assigneeId === originalUserId) {
          updatedTask.assigneeId = newId;
        }
        if (task.creatorId === originalUserId) {
          updatedTask.creatorId = newId;
        }
        return updatedTask;
      }));
    }

    if (loggedInUser?.id === originalUserId) { // If admin edits their own user details (not profile page)
      setLoggedInUser(finalUserData); 
    }
  }, [users, loggedInUser, tasks]);
  
  const handleUpdateUserProfile = useCallback((userId: string, profileData: ProfileFormData) => {
    setUsers(prevUsers => prevUsers.map(user => {
      if (user.id === userId) {
        const updatedUser: User = { 
          ...user,
          name: profileData.name,
          avatarUrl: profileData.avatarUrl === '' ? undefined : (profileData.avatarUrl || user.avatarUrl), 
          designation: profileData.designation,
        };
        if (profileData.password) {
          updatedUser.password = profileData.password;
        }
        // customAssignmentRules are not changed via profile edit
        return updatedUser;
      }
      return user;
    }));
    if (loggedInUser?.id === userId) {
      setLoggedInUser(prevUser => {
        if (!prevUser) return null;
        const updatedLoggedInUser: User = {
            ...prevUser,
            name: profileData.name,
            avatarUrl: profileData.avatarUrl === '' ? undefined : (profileData.avatarUrl || prevUser.avatarUrl),
            designation: profileData.designation,
        };
        if (profileData.password) {
            updatedLoggedInUser.password = profileData.password;
        }
        return updatedLoggedInUser;
      });
    }
  }, [loggedInUser]);


  const handleDeleteUser = useCallback((userId: string) => {
    if (!loggedInUser || loggedInUser.role !== 'admin') {
        alert("Only admins can delete users.");
        return;
    }
    const userToDelete = users.find(u => u.id === userId);
    if (!userToDelete) return;

    const isAdmin = userToDelete.role === 'admin';
    const adminCount = users.filter(u => u.role === 'admin').length;

    if (isAdmin && adminCount === 1 && userToDelete.id === loggedInUser.id) { 
      alert('Cannot delete the last admin user if it is yourself.');
      return;
    }
     if (isAdmin && adminCount === 1 && userToDelete.id !== loggedInUser.id) {
      alert('Cannot delete the last admin user.'); 
      return;
    }

    if (window.confirm('Are you sure you want to delete this user? This will unassign them from all tasks.')) {
      setUsers(prevUsers => prevUsers.filter(user => user.id !== userId));
      setTasks(prevTasks => prevTasks.map(task => task.assigneeId === userId ? { ...task, assigneeId: null } : task));
      if (loggedInUser?.id === userId) {
        handleLogout(); 
      }
    }
  }, [users, loggedInUser, handleLogout]);

  const handleAddTeam = useCallback((newTeamData: Omit<Team, 'id'>) => {
    if (!loggedInUser || loggedInUser.role !== 'admin') {
        alert("Only admins can add teams.");
        return;
    }
    const newTeam: Team = { ...newTeamData, id: crypto.randomUUID() };
    setTeams(prevTeams => [...prevTeams, newTeam]);
  }, [loggedInUser]);

  const handleUpdateTeam = useCallback((updatedTeam: Team) => {
     if (!loggedInUser || loggedInUser.role !== 'admin') {
        alert("Only admins can update teams.");
        return;
    }
    setTeams(prevTeams => prevTeams.map(team => team.id === updatedTeam.id ? updatedTeam : team));
  }, [loggedInUser]);

  const handleDeleteTeam = useCallback((teamId: string) => {
    if (!loggedInUser || loggedInUser.role !== 'admin') {
        alert("Only admins can delete teams.");
        return;
    }
    const usersInTeam = users.filter(user => user.teamId === teamId);
    if (usersInTeam.length > 0) {
      alert('Cannot delete team: Team has users assigned to it. Please reassign users first.');
      return;
    }
    if (window.confirm('Are you sure you want to delete this team?')) {
      setTeams(prevTeams => prevTeams.filter(team => team.id !== teamId));
    }
  }, [users, loggedInUser]);

  const handleUpdateUserAssignmentPermissions = useCallback((userId: string, allowedAssigneeIds: string[]) => {
    if (!loggedInUser || loggedInUser.role !== 'admin') {
      alert("Only admins can change assignment permissions.");
      return;
    }
    setUsers(prevUsers => prevUsers.map(u => 
      u.id === userId ? { ...u, customAssignmentRules: { allowedAssigneeIds } } : u
    ));
  }, [loggedInUser]);

  const handleResetUserAssignmentPermissions = useCallback((userId: string) => {
    if (!loggedInUser || loggedInUser.role !== 'admin') {
      alert("Only admins can change assignment permissions.");
      return;
    }
    setUsers(prevUsers => prevUsers.map(u => 
      u.id === userId ? { ...u, customAssignmentRules: undefined } : u
    ));
  }, [loggedInUser]);


  const navigateTo = useCallback((page: Page) => {
    setCurrentPage(page);
  }, []);

  const renderPage = () => {
    if (!loggedInUser || currentPage === 'login') {
      return <LoginPage onLogin={handleLogin} loginError={loginError} />;
    }
    switch (currentPage) {
      case 'tasks':
        return <TaskList 
                    tasks={tasks} 
                    users={users} 
                    onEditTask={handleOpenModal} 
                    onDeleteTask={handleDeleteTask} 
                    onUpdateTaskStatus={handleUpdateTaskStatus}
                    loggedInUser={loggedInUser}
                />;
      case 'admin':
        if (loggedInUser.role === 'admin') {
          return <AdminPage 
                    users={users} 
                    teams={teams} 
                    onAddUser={handleAddUser} 
                    onUpdateUser={handleUpdateUser} 
                    onDeleteUser={handleDeleteUser} 
                    onAddTeam={handleAddTeam} 
                    onUpdateTeam={handleUpdateTeam} 
                    onDeleteTeam={handleDeleteTeam}
                    onUpdateUserAssignmentPermissions={handleUpdateUserAssignmentPermissions}
                    onResetUserAssignmentPermissions={handleResetUserAssignmentPermissions}
                    loggedInUser={loggedInUser}
                 />;
        }
        console.warn("User tried to access admin page without admin role. Redirecting to tasks.");
        setCurrentPage('tasks'); 
        return <TaskList 
                    tasks={tasks} 
                    users={users} 
                    onEditTask={handleOpenModal} 
                    onDeleteTask={handleDeleteTask} 
                    onUpdateTaskStatus={handleUpdateTaskStatus} 
                    loggedInUser={loggedInUser}
                />;
      case 'profile':
        return <ProfilePage 
                  user={loggedInUser} 
                  onUpdateProfile={handleUpdateUserProfile} 
                  teams={teams} 
                  allUsers={users} 
                  allTasks={tasks}
                />;
      default:
        setLoggedInUser(null); 
        return <LoginPage onLogin={handleLogin} loginError={loginError}/>;
    }
  };

  const isModalVisible = isModalOpen && loggedInUser && (canCreateNewTasks(loggedInUser) || editingTask);

  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
      {loggedInUser && currentPage !== 'login' && (
        <Navbar
          onAddTask={() => handleOpenModal(null)}
          loggedInUser={loggedInUser}
          onNavigate={navigateTo}
          currentPage={currentPage}
          onLogout={handleLogout}
        />
      )}
      <main className={`flex-grow container mx-auto p-4 sm:p-6 lg:p-8 ${!loggedInUser || currentPage === 'login' ? 'flex items-center justify-center min-h-[calc(100vh-4rem)]' : ''}`}>
        {renderPage()}
      </main>
      {isModalVisible && (
        <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingTask ? 'Edit Task' : 'Add New Task'} size="xl">
          <TaskForm
            onSubmit={handleSaveTask}
            initialTask={editingTask}
            users={users}
            onClose={handleCloseModal}
            loggedInUser={loggedInUser!} 
          />
        </Modal>
      )}
    </div>
  );
};

export default App;
