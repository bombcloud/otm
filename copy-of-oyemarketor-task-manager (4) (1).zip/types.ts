export enum TaskStatus {
  Pending = 'PENDING',
  InProgress = 'IN_PROGRESS',
  Completed = 'COMPLETED',
}

export interface Team {
  id: string;
  name: string;
}

export type UserRole = 'admin' | 'user'; // Simplified roles

export interface User {
  id: string; // Also used as username for login
  name: string;
  password?: string; // Store hashed in real app
  avatarUrl?: string;
  teamId: string;
  role: UserRole;
  designation?: string;
  customAssignmentRules?: { // For admin-defined "Can assign to" permissions
    allowedAssigneeIds: string[];
  };
}

export interface Task {
  id: string;
  title: string;
  description: string;
  assigneeId: string | null;
  status: TaskStatus;
  dueDate: string | null; // YYYY-MM-DD format
  createdAt: string; // ISO string
  updatedAt: string; // ISO string
  creatorId?: string; // ID of the user who created the task
}

export type Page = 'tasks' | 'admin' | 'login' | 'profile';