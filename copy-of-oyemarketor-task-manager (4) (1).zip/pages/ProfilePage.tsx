
import React, { useState } from 'react';
import { User, Team, Task } from '../types';
import UserAvatar from '../components/UserAvatar';
import Modal from '../components/Modal';
import ProfileFormModal, { ProfileFormData } from '../components/ProfileFormModal';
import { UserProfileDashboard } from '../components/profile/UserProfileDashboard'; // Changed Import

interface ProfilePageProps {
  user: User; // This is the loggedInUser whose profile is being viewed
  onUpdateProfile: (userId: string, profileData: ProfileFormData) => void;
  teams: Team[];
  allUsers: User[]; // For admin dashboard
  allTasks: Task[]; // For admin dashboard
}

const ProfilePage: React.FC<ProfilePageProps> = ({ user, onUpdateProfile, teams, allUsers, allTasks }) => {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const teamName = teams.find(t => t.id === user.teamId)?.name || 'N/A';

  const handleProfileUpdate = (formData: ProfileFormData) => {
    onUpdateProfile(user.id, formData);
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-8">
      <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 shadow-xl rounded-lg p-6 sm:p-8">
        <div className="flex flex-col items-center sm:flex-row sm:items-start">
          <UserAvatar user={user} size="lg" />
          <div className="mt-4 sm:mt-0 sm:ml-6 text-center sm:text-left">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">{user.name}</h1>
            <p className="text-md text-gray-600 dark:text-gray-400">{user.designation || 'No designation set'}</p>
            <p className="text-sm text-gray-500 dark:text-gray-500">User ID: {user.id}</p>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-8">
          <dl className="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">Role</dt>
              <dd className="mt-1 text-sm text-gray-900 dark:text-gray-100 capitalize">{user.role}</dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500 dark:text-gray-400">Team</dt>
              <dd className="mt-1 text-sm text-gray-900 dark:text-gray-100">{teamName}</dd>
            </div>
          </dl>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="bg-primary hover:bg-primary-hover text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition duration-150 ease-in-out"
          >
            Edit Profile
          </button>
        </div>

        {isEditModalOpen && (
          <Modal isOpen={isEditModalOpen} onClose={() => setIsEditModalOpen(false)} title="Edit Your Profile" size="xl">
            <ProfileFormModal
              initialUser={user}
              onSubmit={handleProfileUpdate}
              onClose={() => setIsEditModalOpen(false)}
            />
          </Modal>
        )}
      </div>

      {user.role === 'admin' && (
        <div className="mt-12">
          <UserProfileDashboard
            adminUser={user}
            allUsers={allUsers}
            allTasks={allTasks}
          />
        </div>
      )}
    </div>
  );
};

export default ProfilePage;