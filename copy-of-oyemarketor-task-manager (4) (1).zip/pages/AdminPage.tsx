
import React, { useState } from 'react';
import { User, Team } from '../types';
import UserManagement from '../components/admin/UserManagement';
import TeamManagement from '../components/admin/TeamManagement';
import { UsersIcon } from '../components/icons/UsersIcon';
import { TeamIcon } from '../components/icons/TeamIcon';
import { UserFormData as AdminUserFormData } from '../components/admin/UserFormModal';

interface AdminPageProps {
  users: User[];
  teams: Team[];
  onAddUser: (user: AdminUserFormData) => void; 
  onUpdateUser: (originalUserId: string, user: AdminUserFormData) => void;
  onDeleteUser: (userId: string) => void;
  onAddTeam: (team: Omit<Team, 'id'>) => void;
  onUpdateTeam: (team: Team) => void;
  onDeleteTeam: (teamId: string) => void;
  onUpdateUserAssignmentPermissions: (userId: string, allowedAssigneeIds: string[]) => void;
  onResetUserAssignmentPermissions: (userId: string) => void;
  loggedInUser: User;
}

type AdminSection = 'users' | 'teams';

const AdminPage: React.FC<AdminPageProps> = (props) => {
  const { loggedInUser } = props;
  const [activeSection, setActiveSection] = useState<AdminSection>('users');

  // Admin page is only accessible to admins, so no need to check role for team management visibility here.
  // The App.tsx routing handles overall page access.

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between pb-4 border-b border-gray-200 dark:border-gray-700">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">Admin Panel</h1>
         <div className="flex space-x-2">
            <button
                onClick={() => setActiveSection('users')}
                aria-pressed={activeSection === 'users'}
                className={`px-4 py-2 rounded-lg flex items-center space-x-2 text-sm font-medium transition-colors
                ${activeSection === 'users' ? 'bg-primary text-white shadow-md' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'}`}
            >
                <UsersIcon className="h-5 w-5" />
                <span>Manage Users</span>
            </button>
            <button
                onClick={() => setActiveSection('teams')}
                aria-pressed={activeSection === 'teams'}
                className={`px-4 py-2 rounded-lg flex items-center space-x-2 text-sm font-medium transition-colors
                ${activeSection === 'teams' ? 'bg-primary text-white shadow-md' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'}`}
            >
                <TeamIcon className="h-5 w-5" />
                <span>Manage Teams</span>
            </button>
        </div>
      </div>

      {activeSection === 'users' && (
        <UserManagement
          users={props.users}
          allUsers={props.users} // Pass allUsers for permission modal
          teams={props.teams}
          onAddUser={props.onAddUser} 
          onUpdateUser={props.onUpdateUser}
          onDeleteUser={props.onDeleteUser}
          onUpdateUserAssignmentPermissions={props.onUpdateUserAssignmentPermissions}
          onResetUserAssignmentPermissions={props.onResetUserAssignmentPermissions}
          loggedInUser={props.loggedInUser}
        />
      )}
      {activeSection === 'teams' && (
        <TeamManagement
          teams={props.teams}
          users={props.users}
          onAddTeam={props.onAddTeam}
          onUpdateTeam={props.onUpdateTeam}
          onDeleteTeam={props.onDeleteTeam}
        />
      )}
    </div>
  );
};

export default AdminPage;