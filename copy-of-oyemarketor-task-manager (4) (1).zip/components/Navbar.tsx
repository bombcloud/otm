
import React, { useState, useEffect, useRef } from 'react';
import { PlusIcon } from './icons/PlusIcon';
import { User, Page } from '../types';
import { UsersIcon } from './icons/UsersIcon';
import { TasksIcon } from './icons/TasksIcon';
import UserAvatar from './UserAvatar';
import { DropdownIcon } from './icons/DropdownIcon';


interface NavbarProps {
  onAddTask: () => void;
  loggedInUser: User | null;
  onNavigate: (page: Page) => void;
  currentPage: Page;
  onLogout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onAddTask, loggedInUser, onNavigate, currentPage, onLogout }) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!loggedInUser) {
    return null; 
  }

  const canAccessAdminPanel = loggedInUser.role === 'admin';
  // canAddTask logic is now primarily determined by App.tsx's canCreateNewTasks,
  // but for Navbar button visibility, we can use a simplified check here.
  // The true permission check happens in App.tsx when opening modal or saving.
  const canShowAddTaskButton = loggedInUser.role === 'admin' || 
                             (loggedInUser.role === 'user' && loggedInUser.customAssignmentRules);


  return (
    <nav className="bg-primary shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <h1 className="text-2xl font-bold text-primary-text mr-6">OyeMarketor Task Manager</h1>
            <button
              onClick={() => onNavigate('tasks')}
              aria-current={currentPage === 'tasks' ? 'page' : undefined}
              className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors
                ${currentPage === 'tasks' 
                  ? 'bg-primary-hover text-white' 
                  : 'text-gray-300 hover:bg-primary-hover hover:text-white'
                }`}
            >
              <TasksIcon className="h-5 w-5 mr-1" />
              Tasks
            </button>
            {canAccessAdminPanel && (
              <button
                onClick={() => onNavigate('admin')}
                aria-current={currentPage === 'admin' ? 'page' : undefined}
                 className={`flex items-center ml-4 px-3 py-2 rounded-md text-sm font-medium transition-colors
                ${currentPage === 'admin' 
                  ? 'bg-primary-hover text-white' 
                  : 'text-gray-300 hover:bg-primary-hover hover:text-white'
                }`}
              >
                <UsersIcon className="h-5 w-5 mr-1" />
                Admin Panel
              </button>
            )}
          </div>
          <div className="flex items-center space-x-4">
           {currentPage === 'tasks' && canShowAddTaskButton && (
            <button
              onClick={onAddTask}
              className="bg-secondary hover:bg-secondary-hover text-secondary-text font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition duration-150 ease-in-out flex items-center space-x-2"
              aria-label="Add new task"
            >
              <PlusIcon className="h-5 w-5" />
              <span>Add New Task</span>
            </button>
           )}
            <div className="relative" ref={dropdownRef}>
              <button 
                onClick={() => setDropdownOpen(!dropdownOpen)} 
                className="flex items-center text-left space-x-2 p-1 rounded-full hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-primary focus:ring-white"
                aria-expanded={dropdownOpen}
                aria-haspopup="true"
              >
                <UserAvatar user={loggedInUser} size="md" />
                <div className="hidden sm:block">
                  <div className="text-sm font-medium text-primary-text">{loggedInUser.name}</div>
                  <div className="text-xs text-gray-300">{loggedInUser.designation || loggedInUser.role}</div>
                </div>
                <DropdownIcon className="h-5 w-5 text-primary-text" />
              </button>
              {dropdownOpen && (
                <div 
                    className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg py-1 bg-white dark:bg-gray-700 ring-1 ring-black ring-opacity-5 focus:outline-none z-50" 
                    role="menu" 
                    aria-orientation="vertical" 
                    aria-labelledby="user-menu-button"
                >
                  <button
                    onClick={() => { onNavigate('profile'); setDropdownOpen(false); }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600"
                    role="menuitem"
                  >
                    View Profile
                  </button>
                  <button
                    onClick={() => { onLogout(); setDropdownOpen(false); }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600"
                    role="menuitem"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;