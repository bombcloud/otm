
import React, { useState, useEffect, useRef } from 'react';
import { User } from '../types';
import UserAvatar from './UserAvatar'; // For preview

export interface ProfileFormData {
  name: string;
  avatarUrl?: string; // Can be base64 data URI or URL string, or undefined
  designation?: string;
  password?: string; // New password
}

interface ProfileFormProps {
  initialUser: User;
  onSubmit: (formData: ProfileFormData) => void;
  onClose: () => void;
}

const ProfileFormModal: React.FC<ProfileFormProps> = ({ initialUser, onSubmit, onClose }) => {
  const [name, setName] = useState('');
  // Store avatar as data URI for preview and submission, or existing URL
  const [avatarPreview, setAvatarPreview] = useState<string | undefined>(initialUser.avatarUrl);
  // Track if avatar was explicitly removed
  const [avatarRemoved, setAvatarRemoved] = useState(false);
  const [designation, setDesignation] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);


  useEffect(() => {
    setName(initialUser.name);
    setAvatarPreview(initialUser.avatarUrl);
    setDesignation(initialUser.designation || '');
    setAvatarRemoved(false); // Reset on initialUser change
  }, [initialUser]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
        setAvatarRemoved(false); // New file uploaded, so not "removed"
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveAvatar = () => {
    setAvatarPreview(undefined);
    setAvatarRemoved(true);
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; // Clear the file input
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);

    if (!name.trim()) {
      alert("Name cannot be empty.");
      return;
    }

    if (newPassword && newPassword !== confirmPassword) {
      setPasswordError("New passwords do not match.");
      return;
    }
    if (newPassword && newPassword.length < 6) {
        setPasswordError("New password must be at least 6 characters long.");
        return;
    }
    
    const formData: ProfileFormData = { 
        name, 
        avatarUrl: avatarRemoved ? '' : avatarPreview, // Send empty string if removed, else preview (which could be base64 or original URL)
        designation 
    };
    if (newPassword) {
      formData.password = newPassword;
    }
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="profileName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Full Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="profileName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Avatar
        </label>
        <div className="mt-1 flex items-center space-x-4">
          <UserAvatar user={{ ...initialUser, avatarUrl: avatarPreview }} size="lg" />
          <input
            type="file"
            id="profileAvatarFile"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileChange}
            className="block w-full text-sm text-gray-500 dark:text-gray-400
                       file:mr-4 file:py-2 file:px-4
                       file:rounded-full file:border-0
                       file:text-sm file:font-semibold
                       file:bg-primary-hover file:text-primary-text
                       hover:file:bg-primary"
          />
        </div>
        {avatarPreview && (
            <button 
                type="button" 
                onClick={handleRemoveAvatar}
                className="mt-2 text-xs text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
            >
                Remove Avatar
            </button>
        )}
      </div>

      <div>
        <label htmlFor="profileDesignation" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Designation
        </label>
        <input
          type="text"
          id="profileDesignation"
          value={designation}
          onChange={(e) => setDesignation(e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
        />
      </div>
      <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">Change Password (Optional)</h3>
         <div>
            <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            New Password
            </label>
            <input
            type="password"
            id="newPassword"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
            />
        </div>
        <div className="mt-4">
            <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Confirm New Password
            </label>
            <input
            type="password"
            id="confirmPassword"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
            />
        </div>
        {passwordError && <p className="text-xs text-red-500 dark:text-red-400 mt-1">{passwordError}</p>}
      </div>


      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm transition"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-hover rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
        >
          Save Changes
        </button>
      </div>
    </form>
  );
};

export default ProfileFormModal;
