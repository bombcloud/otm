
import React from 'react';

export const SortDescendingIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.472 13.972a.75.75 0 01-.22-.53V5.25a.75.75 0 011.39-.22L13.26 10.55l1.61-1.61a.75.75 0 111.06 1.06l-2.75 2.75a.75.75 0 01-1.06 0l-2.632-2.632v2.235a.75.75 0 01-1.01.73zM15 15.25a.75.75 0 000-1.5h-3.75a.75.75 0 000 1.5H15zM15 12.25a.75.75 0 000-1.5h-2.25a.75.75 0 000 1.5H15zM15 9.25a.75.75 0 000-1.5H8.25a.75.75 0 000 1.5H15zM15 6.25a.75.75 0 000-1.5H6.75a.75.75 0 000 1.5H15z" clipRule="evenodd" />
  </svg>
);