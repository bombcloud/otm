import React from 'react';

// A simple representation of a team or group of users
export const TeamIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-3.741-5.588M14.25 10.5a8.25 8.25 0 1 0 0 16.5 8.25 8.25 0 0 0 0-16.5Zm0 0H8.25m0 0A8.25 8.25 0 0 1 0 10.5a8.25 8.25 0 0 1 16.5 0H8.25Zm6.75-3.75a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z M3.75 10.5a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
  </svg>
);