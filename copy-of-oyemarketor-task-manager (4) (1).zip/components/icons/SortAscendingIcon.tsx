
import React from 'react';

export const SortAscendingIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.472 6.028a.75.75 0 01.22.53v8.192a.75.75 0 01-1.39.22L7.69 9.449l-1.61 1.611a.75.75 0 01-1.06-1.061l2.75-2.75a.75.75 0 011.06 0l2.632 2.632V6.558a.75.75 0 011.01-.73zM15 4.75a.75.75 0 000-1.5h-3.75a.75.75 0 000 1.5H15zM15 7.75a.75.75 0 000-1.5h-2.25a.75.75 0 000 1.5H15zM15 10.75a.75.75 0 000-1.5H8.25a.75.75 0 000 1.5H15zM15 13.75a.75.75 0 000-1.5H6.75a.75.75 0 000 1.5H15z" clipRule="evenodd" />
  </svg>
);