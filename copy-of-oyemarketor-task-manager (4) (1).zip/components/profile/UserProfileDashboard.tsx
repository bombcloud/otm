
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { User, Task, TaskStatus } from '../../types';
import { CalendarDaysIcon } from '../icons/CalendarDaysIcon';
import { ChartBarIcon } from '../icons/ChartBarIcon';
import { FilterIcon } from '../icons/FilterIcon';

// Declare Chart.js to TypeScript if using CDN and no explicit types package
declare const Chart: any;

interface UserProfileDashboardProps {
  adminUser: User;
  allUsers: User[];
  allTasks: Task[];
}

export const UserProfileDashboard: React.FC<UserProfileDashboardProps> = ({ adminUser, allUsers, allTasks }) => {
  const [selectedUserIdForReport, setSelectedUserIdForReport] = useState<string | null>(null);
  const [selectedDateForReport, setSelectedDateForReport] = useState<string>(new Date().toISOString().split('T')[0]);

  const statusPieChartRef = useRef<HTMLCanvasElement>(null);
  const statusChartInstanceRef = useRef<any>(null);
  const completionBarChartRef = useRef<HTMLCanvasElement>(null);
  const completionChartInstanceRef = useRef<any>(null);


  const selectedUser = useMemo(() => {
    return allUsers.find(u => u.id === selectedUserIdForReport) || null;
  }, [selectedUserIdForReport, allUsers]);

  const dailyReportTasks = useMemo(() => {
    if (!selectedUser || !selectedDateForReport) return [];
    
    const reportDate = new Date(selectedDateForReport + 'T00:00:00.000Z'); 

    return allTasks.filter(task => {
      const taskDueDate = task.dueDate ? new Date(task.dueDate + 'T00:00:00.000Z') : null;
      const taskCreatedAt = new Date(task.createdAt);

      const isRelevant = 
        (task.assigneeId === selectedUser.id && taskCreatedAt.toISOString().split('T')[0] <= selectedDateForReport) || 
        task.creatorId === selectedUser.id && taskCreatedAt.toISOString().split('T')[0] === selectedDateForReport || 
        (taskDueDate && taskDueDate.toISOString().split('T')[0] === selectedDateForReport); 

      return isRelevant;
    }).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [selectedUser, selectedDateForReport, allTasks]);

  const taskStatistics = useMemo(() => {
    if (!selectedUser) return null;
    const userTasks = allTasks.filter(task => task.assigneeId === selectedUser.id || task.creatorId === selectedUser.id);
    
    const total = userTasks.length;
    const pending = userTasks.filter(t => t.status === TaskStatus.Pending).length;
    const inProgress = userTasks.filter(t => t.status === TaskStatus.InProgress).length;
    const completed = userTasks.filter(t => t.status === TaskStatus.Completed).length;

    let onTime = 0;
    let overdue = 0;
    userTasks.filter(t => t.status === TaskStatus.Completed).forEach(t => {
      if (t.dueDate) {
        const dueDate = new Date(t.dueDate + 'T23:59:59.999Z'); 
        const completedAt = new Date(t.updatedAt);
        if (completedAt <= dueDate) {
          onTime++;
        } else {
          overdue++;
        }
      } else {
        onTime++;
      }
    });
    return { total, pending, inProgress, completed, onTime, overdue };
  }, [selectedUser, allTasks]);

  const getTaskCompletionStatus = (task: Task): string => {
    if (task.status !== TaskStatus.Completed) return 'N/A';
    if (!task.dueDate) return 'On Time (No Due Date)';
    const dueDate = new Date(task.dueDate + 'T23:59:59.999Z');
    const completedAt = new Date(task.updatedAt);
    return completedAt <= dueDate ? 'On Time' : 'Overdue';
  };

  // Effect for Status Pie Chart
  useEffect(() => {
    if (statusPieChartRef.current && taskStatistics) {
      if (statusChartInstanceRef.current) {
        statusChartInstanceRef.current.destroy();
      }
      const ctx = statusPieChartRef.current.getContext('2d');
      if (ctx) {
        statusChartInstanceRef.current = new Chart(ctx, {
          type: 'pie',
          data: {
            labels: ['Pending', 'In Progress', 'Completed'],
            datasets: [{
              label: 'Task Statuses',
              data: [taskStatistics.pending, taskStatistics.inProgress, taskStatistics.completed],
              backgroundColor: [
                'rgba(250, 204, 21, 0.7)', // Tailwind yellow-400
                'rgba(59, 130, 246, 0.7)', // Tailwind blue-500
                'rgba(16, 185, 129, 0.7)', // Tailwind emerald-500
              ],
              borderColor: [
                'rgba(250, 204, 21, 1)',
                'rgba(59, 130, 246, 1)',
                'rgba(16, 185, 129, 1)',
              ],
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                position: 'top',
                labels: {
                    color: document.body.classList.contains('dark') ? '#E5E7EB' : '#374151', // Adjust for dark mode
                }
              },
              tooltip: {
                callbacks: {
                    label: function(context: any) {
                        let label = context.label || '';
                        if (label) {
                            label += ': ';
                        }
                        if (context.parsed !== null) {
                            label += context.parsed;
                        }
                        const total = context.dataset.data.reduce((acc: number, val: number) => acc + val, 0);
                        const percentage = total > 0 ? ((context.parsed / total) * 100).toFixed(1) + '%' : '0%';
                        label += ` (${percentage})`;
                        return label;
                    }
                }
              }
            }
          }
        });
      }
    }
    return () => {
      if (statusChartInstanceRef.current) {
        statusChartInstanceRef.current.destroy();
        statusChartInstanceRef.current = null;
      }
    };
  }, [taskStatistics]);

  // Effect for Completion Bar Chart
  useEffect(() => {
    if (completionBarChartRef.current && taskStatistics && taskStatistics.completed > 0) {
      if (completionChartInstanceRef.current) {
        completionChartInstanceRef.current.destroy();
      }
      const ctx = completionBarChartRef.current.getContext('2d');
      if (ctx) {
        completionChartInstanceRef.current = new Chart(ctx, {
          type: 'bar',
          data: {
            labels: ['On Time', 'Overdue'],
            datasets: [{
              label: 'Completed Tasks',
              data: [taskStatistics.onTime, taskStatistics.overdue],
              backgroundColor: [
                'rgba(16, 185, 129, 0.7)', // Tailwind emerald-500
                'rgba(239, 68, 68, 0.7)'  // Tailwind red-500
              ],
              borderColor: [
                'rgba(16, 185, 129, 1)',
                'rgba(239, 68, 68, 1)'
              ],
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  stepSize: 1,
                  color: document.body.classList.contains('dark') ? '#E5E7EB' : '#374151',
                },
                 grid: {
                    color: document.body.classList.contains('dark') ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)',
                }
              },
              x: {
                 ticks: {
                    color: document.body.classList.contains('dark') ? '#E5E7EB' : '#374151',
                },
                grid: {
                    display: false,
                }
              }
            },
            plugins: {
              legend: {
                display: false
              }
            }
          }
        });
      }
    } else if (completionChartInstanceRef.current) { // Clear chart if no completed tasks
        completionChartInstanceRef.current.destroy();
        completionChartInstanceRef.current = null;
    }
    return () => {
      if (completionChartInstanceRef.current) {
        completionChartInstanceRef.current.destroy();
        completionChartInstanceRef.current = null;
      }
    };
  }, [taskStatistics]);


  return (
    <div className="bg-white dark:bg-gray-800 shadow-xl rounded-lg p-6 sm:p-8 space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center">
          <ChartBarIcon className="h-7 w-7 mr-2 text-primary" />
          User Activity Dashboard
        </h2>
        <div className="mb-6">
          <label htmlFor="userSelectorForReport" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Select User for Report:
          </label>
          <select
            id="userSelectorForReport"
            value={selectedUserIdForReport || ''}
            onChange={(e) => setSelectedUserIdForReport(e.target.value || null)}
            className="w-full max-w-xs px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
          >
            <option value="">-- Select a User --</option>
            {allUsers.map(user => (
              <option key={user.id} value={user.id}>
                {user.name} ({user.id})
              </option>
            ))}
          </select>
        </div>
      </div>

      {!selectedUser && (
        <p className="text-gray-500 dark:text-gray-400 text-center py-4">Please select a user to view their activity report.</p>
      )}

      {selectedUser && (
        <>
          <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">
              Session Activity for {selectedUser.name}
            </h3>
            <div className="bg-yellow-50 dark:bg-yellow-900 border-l-4 border-yellow-400 dark:border-yellow-500 p-4 rounded-md">
              <p className="text-sm text-yellow-700 dark:text-yellow-200">
                <strong>Note:</strong> Detailed daily login time tracking (e.g., exact login/logout times, total session duration per day)
                requires a backend system for accurate and persistent logging. This frontend-only application cannot reliably track this historical data.
              </p>
            </div>
          </div>

          <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
            <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
              <CalendarDaysIcon className="h-6 w-6 mr-2 text-primary" />
              Daily Tasks Report for {selectedUser.name}
            </h3>
            <div className="mb-4">
              <label htmlFor="reportDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Select Date:
              </label>
              <input
                type="date"
                id="reportDate"
                value={selectedDateForReport}
                onChange={(e) => setSelectedDateForReport(e.target.value)}
                className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
              />
            </div>

            {dailyReportTasks.length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400">No tasks found for {selectedUser.name} on {new Date(selectedDateForReport  + 'T00:00:00').toLocaleDateString()}.</p>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Title</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Status</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Due Date</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Completion</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    {dailyReportTasks.map(task => (
                      <tr key={task.id}>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{task.title}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{task.status}</td>
                        <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{task.dueDate ? new Date(task.dueDate + 'T00:00:00').toLocaleDateString() : 'N/A'}</td>
                        <td className={`px-4 py-2 whitespace-nowrap text-sm ${getTaskCompletionStatus(task) === 'Overdue' ? 'text-red-500 dark:text-red-400' : (getTaskCompletionStatus(task) === 'N/A' ? 'text-gray-500 dark:text-gray-400' : 'text-green-500 dark:text-green-400')}`}>
                          {getTaskCompletionStatus(task)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {taskStatistics && (
            <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
              <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4 flex items-center">
                <FilterIcon className="h-5 w-5 mr-2 text-primary" />
                Overall Task Statistics for {selectedUser.name}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                  <h4 className="text-md font-semibold text-gray-700 dark:text-gray-200 mb-2">Task Status Distribution</h4>
                   {(taskStatistics.pending > 0 || taskStatistics.inProgress > 0 || taskStatistics.completed > 0) ? (
                    <div className="relative h-64 md:h-72"> {/* Added md:h-72 for larger screens */}
                        <canvas ref={statusPieChartRef}></canvas>
                    </div>
                   ) : (
                     <p className="text-sm text-gray-500 dark:text-gray-400">No tasks with these statuses to display.</p>
                   )}
                </div>
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                  <h4 className="text-md font-semibold text-gray-700 dark:text-gray-200 mb-2">Completed Task Breakdown</h4>
                  {taskStatistics.completed > 0 ? (
                    <div className="relative h-64 md:h-72"> {/* Added md:h-72 for larger screens */}
                        <canvas ref={completionBarChartRef}></canvas>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500 dark:text-gray-400">No completed tasks to display statistics for.</p>
                  )}
                </div>
              </div>
               <div className="mt-6 bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                  <p className="text-md font-semibold text-gray-700 dark:text-gray-200 mb-1">Summary Figures:</p>
                  <ul className="list-disc list-inside text-sm text-gray-600 dark:text-gray-300 space-y-1">
                    <li>Total Tasks (Assigned/Created): <span className="font-bold text-primary">{taskStatistics.total}</span></li>
                    <li>Pending: <span className="font-bold" style={{color: 'rgba(250, 204, 21, 1)'}}>{taskStatistics.pending}</span></li>
                    <li>In Progress: <span className="font-bold" style={{color: 'rgba(59, 130, 246, 1)'}}>{taskStatistics.inProgress}</span></li>
                    <li>Completed: <span className="font-bold" style={{color: 'rgba(16, 185, 129, 1)'}}>{taskStatistics.completed}</span></li>
                    {taskStatistics.completed > 0 && (
                        <>
                        <li>&nbsp;&nbsp;&nbsp;└ On Time: <span className="font-bold" style={{color: 'rgba(16, 185, 129, 1)'}}>{taskStatistics.onTime}</span></li>
                        <li>&nbsp;&nbsp;&nbsp;└ Overdue: <span className="font-bold" style={{color: 'rgba(239, 68, 68, 1)'}}>{taskStatistics.overdue}</span></li>
                        </>
                    )}
                  </ul>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
// Removed export default UserProfileDashboard;
