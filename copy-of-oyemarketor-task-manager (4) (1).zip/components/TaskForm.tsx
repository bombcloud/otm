
import React, { useState, useEffect, useMemo } from 'react';
import { Task, User, TaskStatus } from '../types';
import { STATUS_OPTIONS } from '../constants';

interface TaskFormProps {
  onSubmit: (taskData: Omit<Task, 'id' | 'createdAt' | 'updatedAt' | 'creatorId'> | Task) => void;
  initialTask?: Task | null;
  users: User[];
  onClose: () => void;
  loggedInUser: User; 
}

export const TaskForm: React.FC<TaskFormProps> = ({ onSubmit, initialTask, users, onClose, loggedInUser }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [assigneeId, setAssigneeId] = useState<string | null>(null);
  const [status, setStatus] = useState<TaskStatus>(TaskStatus.Pending);
  const [dueDate, setDueDate] = useState<string | null>(null);

  const assignableUsers = useMemo(() => {
    if (!loggedInUser) return [];

    if (loggedInUser.role === 'admin') return users;

    if (loggedInUser.role === 'user') {
      if (loggedInUser.customAssignmentRules && loggedInUser.customAssignmentRules.allowedAssigneeIds) {
        const allowedIds = new Set(loggedInUser.customAssignmentRules.allowedAssigneeIds);
        // User should also be able to assign to themselves or unassign.
        // Self-assignment is implicit if their ID is in allowedAssigneeIds or if they create a task for self.
        return users.filter(u => allowedIds.has(u.id));
      }
    }
    // Default for users without custom rules: empty list (can only create unassigned or self-assigned if form allows)
    // Or if editing their own task, they can only unassign or keep current assignee.
    return []; 
  }, [users, loggedInUser]);

  const creatorOfTask = useMemo(() => {
    if (initialTask?.creatorId) {
        return users.find(u => u.id === initialTask.creatorId);
    }
    return null;
  }, [initialTask, users]);

  useEffect(() => {
    if (initialTask) {
      setTitle(initialTask.title);
      setDescription(initialTask.description);
      setAssigneeId(initialTask.assigneeId);
      setStatus(initialTask.status);
      setDueDate(initialTask.dueDate);
    } else {
      setTitle('');
      setDescription('');
      // For new tasks, if user has custom rules and only one allowed assignee, pre-select them? Or leave null.
      // Leaving null for now to allow unassigned/self-assigned.
      setAssigneeId(null); 
      setStatus(TaskStatus.Pending);
      setDueDate(null);
    }
  }, [initialTask]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
        alert("Title is required.");
        return;
    }
    const taskData = {
      title,
      description,
      assigneeId,
      status,
      dueDate,
    };
    
    const finalTaskData = initialTask && initialTask.id 
        ? { ...initialTask, ...taskData } 
        : { ...taskData, creatorId: loggedInUser.id }; 

    onSubmit(finalTaskData);
  };
  
  const canEditDetails = () => {
    if (loggedInUser.role === 'admin') return true;
    if (initialTask) { // Editing
        return initialTask.creatorId === loggedInUser.id || initialTask.assigneeId === loggedInUser.id;
    }
    // Creating: if they can open the form, they can edit details
    return !!loggedInUser.customAssignmentRules;
  }

  const disableAssigneeField = () => {
    // Admin can always change assignee.
    if (loggedInUser.role === 'admin') return false;

    // User creating a new task: enabled if they have custom rules.
    if (!initialTask && loggedInUser.role === 'user' && loggedInUser.customAssignmentRules) {
        return false;
    }
    // User editing a task:
    if (initialTask && loggedInUser.role === 'user') {
        // Can change assignee if they have custom rules AND are creator or assignee.
        if ((initialTask.creatorId === loggedInUser.id || initialTask.assigneeId === loggedInUser.id) && loggedInUser.customAssignmentRules) {
            return false;
        }
    }
    // Default to disabled for users without specific permissions.
    return true;
  }


  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Title <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
          disabled={!canEditDetails()}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
        />
      </div>

      <div>
        <label htmlFor="description" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Description
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={4}
          disabled={!canEditDetails()}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
        />
      </div>

      {initialTask && creatorOfTask && (
        <div>
          <p className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Task Information
          </p>
          <div className="mt-1 p-3 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
            <span className="text-sm text-gray-600 dark:text-gray-400">
                Created by: <span className="font-semibold text-gray-700 dark:text-gray-300">{creatorOfTask.name}</span> on {new Date(initialTask.createdAt).toLocaleDateString()}
            </span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        <div>
          <label htmlFor="assigneeId" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Assignee
          </label>
          <select
            id="assigneeId"
            value={assigneeId || ''}
            onChange={(e) => setAssigneeId(e.target.value || null)}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
            disabled={disableAssigneeField()} 
          >
            <option value="">Unassigned</option>
            {/* If user is editing their own task, and assignee field is disabled, they should still see the current assignee if one exists */}
            {disableAssigneeField() && initialTask && initialTask.assigneeId && !assignableUsers.find(u => u.id === initialTask.assigneeId) &&
                users.find(u => u.id === initialTask.assigneeId) && (
                <option key={initialTask.assigneeId} value={initialTask.assigneeId}>
                    {users.find(u => u.id === initialTask.assigneeId)!.name} ({users.find(u => u.id === initialTask.assigneeId)!.designation || users.find(u => u.id === initialTask.assigneeId)!.role})
                </option>
            )}
            {assignableUsers.map(user => (
              <option key={user.id} value={user.id}>
                {user.name} ({user.designation || user.role})
              </option>
            ))}
          </select>
          {assignableUsers.length === 0 && !assigneeId && loggedInUser.role === 'user' && !disableAssigneeField() && (
            <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
              You currently have no permissions to assign tasks to other users. Task can be unassigned or self-assigned.
            </p>
          )}
        </div>

        <div>
          <label htmlFor="status" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Status
          </label>
          <select
            id="status"
            value={status}
            onChange={(e) => setStatus(e.target.value as TaskStatus)}
            disabled={!canEditDetails() && !(initialTask?.assigneeId === loggedInUser.id)}
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
          >
            {STATUS_OPTIONS.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div>
        <label htmlFor="dueDate" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Due Date
        </label>
        <input
          type="date"
          id="dueDate"
          value={dueDate || ''}
          onChange={(e) => setDueDate(e.target.value || null)}
          disabled={!canEditDetails()}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm transition"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={ !canEditDetails() && !(loggedInUser.role === 'admin' || (loggedInUser.role === 'user' && loggedInUser.customAssignmentRules)) }
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-hover rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {initialTask ? 'Save Changes' : 'Create Task'}
        </button>
      </div>
    </form>
  );
};
