
import React from 'react';
import { User, Task, TaskStatus } from '../types';
import UserAvatar from './UserAvatar';

interface LiveActivityTableProps {
  users: User[];
  tasks: Task[];
  onUserSelect: (userId: string) => void; // New prop for handling user clicks
}

interface UserActivitySummary {
  user: User;
  pending: number;
  inProgress: number;
  completed: number;
}

const LiveActivityTable: React.FC<LiveActivityTableProps> = ({ users, tasks, onUserSelect }) => {
  const activitySummary: UserActivitySummary[] = users.map(user => {
    const userTasks = tasks.filter(task => task.assigneeId === user.id);
    return {
      user,
      pending: userTasks.filter(task => task.status === TaskStatus.Pending).length,
      inProgress: userTasks.filter(task => task.status === TaskStatus.InProgress).length,
      completed: userTasks.filter(task => task.status === TaskStatus.Completed).length,
    };
  });

  return (
    <div className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg mb-6 max-w-5xl mx-auto">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-4">Team Live Activity</h2>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Team Member
              </th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Pending
              </th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                In Progress
              </th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                Completed
              </th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {activitySummary.map(({ user, pending, inProgress, completed }) => (
              <tr key={user.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <UserAvatar user={user} size="md" />
                    <div className="ml-4">
                      <button
                        onClick={() => onUserSelect(user.id)}
                        className="text-sm font-medium text-primary dark:text-blue-400 hover:text-primary-hover dark:hover:text-blue-300 underline focus:outline-none"
                        aria-label={`View tasks for ${user.name}`}
                      >
                        {user.name}
                      </button>
                      <div className="text-xs text-gray-500 dark:text-gray-400">{user.designation || user.role}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300 text-center">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${pending > 0 ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-700 dark:text-yellow-100' : 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-100'}`}>
                    {pending}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300 text-center">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${inProgress > 0 ? 'bg-blue-100 text-blue-800 dark:bg-blue-700 dark:text-blue-100' : 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-100'}`}>
                    {inProgress}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300 text-center">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${completed > 0 ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-gray-100 text-gray-800 dark:bg-gray-600 dark:text-gray-100'}`}>
                    {completed}
                  </span>
                </td>
              </tr>
            ))}
            {activitySummary.length === 0 && (
              <tr>
                <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                  No users to display activity for.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LiveActivityTable;