
import React from 'react';
import { User } from '../types';
import { UserCircleIcon } from './icons/UserCircleIcon';

interface UserAvatarProps {
  user?: User;
  size?: 'sm' | 'md' | 'lg';
}

const UserAvatar: React.FC<UserAvatarProps> = ({ user, size = 'md' }) => {
  const sizeClasses = {
    sm: 'h-6 w-6 text-xs',
    md: 'h-8 w-8 text-sm',
    lg: 'h-12 w-12 text-base',
  };

  // Check if avatarUrl is a data URI or an HTTP/HTTPS URL
  const isDataUrl = user?.avatarUrl?.startsWith('data:image');
  const isHttpUrl = user?.avatarUrl?.startsWith('http');
  const showImage = user?.avatarUrl && (isDataUrl || isHttpUrl);


  if (!showImage) {
    const initials = user?.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase() : '';
    return (
      <div className={`flex items-center justify-center bg-gray-300 dark:bg-gray-600 rounded-full ${sizeClasses[size]} text-gray-700 dark:text-gray-200 font-semibold overflow-hidden`}>
        {initials ? initials.substring(0,2) : <UserCircleIcon className="h-full w-full text-gray-400 dark:text-gray-500"/>}
      </div>
    );
  }

  return (
    <img
      src={user.avatarUrl} // This will handle both standard URLs and base64 data URIs
      alt={user.name || 'User Avatar'}
      className={`rounded-full object-cover ${sizeClasses[size]}`}
      onError={(e) => { 
        // Fallback if image fails to load (e.g. broken URL, though less likely for base64)
        // This provides a basic fallback mechanism. A more robust solution might involve
        // setting state to render initials if onError is triggered.
        const target = e.target as HTMLImageElement;
        target.style.display = 'none'; 
        // Create and append initials div as a sibling
        const parent = target.parentNode;
        if (parent) {
            const initialsDiv = document.createElement('div');
            initialsDiv.className = `flex items-center justify-center bg-gray-300 dark:bg-gray-600 rounded-full ${sizeClasses[size]} text-gray-700 dark:text-gray-200 font-semibold overflow-hidden`;
            const initials = user?.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0,2) : '';
            if (initials) {
                initialsDiv.textContent = initials;
            } else {
                // For a true React way, this should re-render with UserCircleIcon
                // This direct DOM manipulation is a quick fix for onError
                const svgNS = "http://www.w3.org/2000/svg";
                const svg = document.createElementNS(svgNS, "svg");
                svg.setAttribute("fill", "none");
                svg.setAttribute("viewBox", "0 0 24 24");
                svg.setAttribute("stroke-width", "1.5");
                svg.setAttribute("stroke", "currentColor");
                svg.classList.add("h-full", "w-full", "text-gray-400", "dark:text-gray-500");
                const path = document.createElementNS(svgNS, "path");
                path.setAttribute("stroke-linecap", "round");
                path.setAttribute("stroke-linejoin", "round");
                path.setAttribute("d", "M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.963 0a9 9 0 1 0-11.963 0m11.963 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z");
                svg.appendChild(path);
                initialsDiv.appendChild(svg);
            }
            parent.appendChild(initialsDiv);
        }
      }}
    />
  );
};

export default UserAvatar;
