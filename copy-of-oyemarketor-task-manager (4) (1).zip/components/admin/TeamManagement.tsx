import React, { useState } from 'react';
import { Team, User } from '../../types';
import Modal from '../Modal';
import TeamForm, { TeamFormData } from './TeamFormModal'; // Renamed for clarity
import { PlusIcon } from '../icons/PlusIcon';
import { EditIcon } from '../icons/EditIcon';
import { TrashIcon } from '../icons/TrashIcon';

interface TeamManagementProps {
  teams: Team[];
  users: User[]; // Needed to check if team can be deleted
  onAddTeam: (team: TeamFormData) => void;
  onUpdateTeam: (team: Team) => void;
  onDeleteTeam: (teamId: string) => void;
}

const TeamManagement: React.FC<TeamManagementProps> = ({ teams, users, onAddTeam, onUpdateTeam, onDeleteTeam }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeam, setEditingTeam] = useState<Team | null>(null);

  const handleOpenModal = (team: Team | null = null) => {
    setEditingTeam(team);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTeam(null);
  };

  const handleSaveTeam = (teamData: TeamFormData) => {
    if (editingTeam) {
      onUpdateTeam({ ...editingTeam, ...teamData });
    } else {
      onAddTeam(teamData);
    }
    handleCloseModal();
  };

  const countUsersInTeam = (teamId: string) => {
    return users.filter(user => user.teamId === teamId).length;
  };

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Teams</h2>
        <button
          onClick={() => handleOpenModal()}
          className="bg-primary hover:bg-primary-hover text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition duration-150 ease-in-out flex items-center space-x-2"
        >
          <PlusIcon className="h-5 w-5" />
          <span>Add Team</span>
        </button>
      </div>

      {teams.length === 0 ? (
         <p className="text-gray-500 dark:text-gray-400 text-center py-4">No teams found. Add a new team to get started.</p>
      ) : (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Members</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {teams.map((team) => (
              <tr key={team.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">{team.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{countUsersInTeam(team.id)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  <button onClick={() => handleOpenModal(team)} className="text-primary hover:text-primary-hover p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" aria-label="Edit team">
                    <EditIcon className="h-5 w-5" />
                  </button>
                  <button onClick={() => onDeleteTeam(team.id)} className="text-danger hover:text-danger-hover p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" aria-label="Delete team">
                    <TrashIcon className="h-5 w-5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      )}

      {isModalOpen && (
        <Modal isOpen={isModalOpen} onClose={handleCloseModal} title={editingTeam ? 'Edit Team' : 'Add Team'}>
          <TeamForm
            onSubmit={handleSaveTeam}
            initialTeam={editingTeam}
            onClose={handleCloseModal}
          />
        </Modal>
      )}
    </div>
  );
};

export default TeamManagement;