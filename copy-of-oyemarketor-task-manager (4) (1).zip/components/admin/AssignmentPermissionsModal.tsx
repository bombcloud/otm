
import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import Modal from '../Modal';
import UserAvatar from '../UserAvatar';

interface AssignmentPermissionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: User;
  allUsers: User[];
  onSavePermissions: (targetUserId: string, allowedAssigneeIds: string[]) => void;
  onResetPermissions: (targetUserId: string) => void;
}

const AssignmentPermissionsModal: React.FC<AssignmentPermissionsModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  allUsers,
  onSavePermissions,
  onResetPermissions,
}) => {
  const [selectedUserIds, setSelectedUserIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (targetUser?.customAssignmentRules?.allowedAssigneeIds) {
      setSelectedUserIds(new Set(targetUser.customAssignmentRules.allowedAssigneeIds));
    } else {
      setSelectedUserIds(new Set());
    }
  }, [targetUser]);

  const handleToggleUser = (userId: string) => {
    setSelectedUserIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(userId)) {
        newSet.delete(userId);
      } else {
        newSet.add(userId);
      }
      return newSet;
    });
  };

  const handleSave = () => {
    onSavePermissions(targetUser.id, Array.from(selectedUserIds));
  };

  const handleReset = () => {
    onResetPermissions(targetUser.id);
  };

  // Filter out the target user from the list of users they can be assigned to
  const assignableUsersList = allUsers.filter(u => u.id !== targetUser.id);

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Assignment Permissions for ${targetUser.name}`} size="xl">
      <div className="space-y-6">
        <p className="text-sm text-gray-600 dark:text-gray-300">
          Select users that <span className="font-semibold">{targetUser.name}</span> can assign tasks to.
          If no users are selected, {targetUser.name} will only be able to assign tasks to themselves or create unassigned tasks (if they have task creation rights).
        </p>
        
        {assignableUsersList.length === 0 ? (
            <p className="text-sm text-gray-500 dark:text-gray-400">No other users available to select for assignment permissions.</p>
        ) : (
            <div className="max-h-96 overflow-y-auto space-y-3 pr-2">
            {assignableUsersList.map(user => (
                <label key={user.id} className="flex items-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors cursor-pointer">
                <input
                    type="checkbox"
                    className="h-5 w-5 text-primary rounded border-gray-300 dark:border-gray-500 focus:ring-primary dark:focus:ring-offset-gray-700"
                    checked={selectedUserIds.has(user.id)}
                    onChange={() => handleToggleUser(user.id)}
                />
                <UserAvatar user={user} size="md" />
                <span className="ml-3 text-sm font-medium text-gray-800 dark:text-gray-100">{user.name}</span>
                <span className="ml-auto text-xs text-gray-500 dark:text-gray-400">{user.designation || user.role}</span>
                </label>
            ))}
            </div>
        )}

        <div className="flex justify-between items-center pt-4 border-t border-gray-200 dark:border-gray-700 mt-6">
          <button
            type="button"
            onClick={handleReset}
            className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm transition"
          >
            Reset to Default (No Custom Rules)
          </button>
          <div className="space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm transition"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-hover rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
            >
              Save Permissions
            </button>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default AssignmentPermissionsModal;