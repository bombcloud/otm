
import React, { useState, useMemo } from 'react';
import { User, Team, UserRole } from '../../types';
import Modal from '../Modal';
import UserForm, { UserFormData } from './UserFormModal';
import AssignmentPermissionsModal from './AssignmentPermissionsModal';
import { PlusIcon } from '../icons/PlusIcon';
import { EditIcon } from '../icons/EditIcon';
import { TrashIcon } from '../icons/TrashIcon';
import { ShieldCheckIcon } from '../icons/ShieldCheckIcon'; // Corrected import path
import UserAvatar from '../UserAvatar';

interface UserManagementProps {
  users: User[]; // Users to display/manage (could be filtered by AdminPage if needed, but here it's all)
  allUsers: User[]; // Complete list of users for permission selection
  teams: Team[];
  onAddUser: (user: UserFormData) => void;
  onUpdateUser: (originalUserId: string, user: UserFormData) => void;
  onDeleteUser: (userId: string) => void;
  onUpdateUserAssignmentPermissions: (userId: string, allowedAssigneeIds: string[]) => void;
  onResetUserAssignmentPermissions: (userId: string) => void;
  loggedInUser: User; 
}

const UserManagement: React.FC<UserManagementProps> = ({ 
    users, 
    allUsers, 
    teams, 
    onAddUser, 
    onUpdateUser, 
    onDeleteUser, 
    onUpdateUserAssignmentPermissions,
    onResetUserAssignmentPermissions,
    loggedInUser 
}) => {
  const [isUserFormModalOpen, setIsUserFormModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  const [isPermissionsModalOpen, setIsPermissionsModalOpen] = useState(false);
  const [userForPermissions, setUserForPermissions] = useState<User | null>(null);


  const handleOpenUserFormModal = (user: User | null = null) => {
    // Only admins can open this modal
    if (loggedInUser.role !== 'admin') {
        alert("Access denied.");
        return;
    }
    setEditingUser(user);
    setIsUserFormModalOpen(true);
  };

  const handleCloseUserFormModal = () => {
    setIsUserFormModalOpen(false);
    setEditingUser(null);
  };

  const handleSaveUser = (userData: UserFormData) => {
    if (editingUser) {
      onUpdateUser(editingUser.id, userData); 
    } else {
      onAddUser(userData);
    }
    handleCloseUserFormModal();
  };

  const handleOpenPermissionsModal = (user: User) => {
    setUserForPermissions(user);
    setIsPermissionsModalOpen(true);
  };

  const handleClosePermissionsModal = () => {
    setIsPermissionsModalOpen(false);
    setUserForPermissions(null);
  };

  const handleSavePermissions = (targetUserId: string, allowedIds: string[]) => {
    onUpdateUserAssignmentPermissions(targetUserId, allowedIds);
    handleClosePermissionsModal();
  };
  
  const handleResetPermissions = (targetUserId: string) => {
    onResetUserAssignmentPermissions(targetUserId);
    handleClosePermissionsModal();
  };

  const getTeamName = (teamId: string) => teams.find(t => t.id === teamId)?.name || 'N/A';

  const canPerformActionOnUser = (targetUser: User): { canEdit: boolean, canDelete: boolean, canEditPermissions: boolean } => {
    if (loggedInUser.role === 'admin') {
      const isTargetAdmin = targetUser.role === 'admin';
      const adminCount = users.filter(u => u.role === 'admin').length;
      const isSelf = targetUser.id === loggedInUser.id;
      
      const canDelete = !(isSelf && isTargetAdmin && adminCount === 1) && !(targetUser.id !== loggedInUser.id && isTargetAdmin && adminCount ===1 );

      return { 
        canEdit: true, 
        canDelete,
        canEditPermissions: targetUser.role === 'user' // Admin can edit permissions for 'user' roles
      };
    }
    // Non-admins shouldn't be able to perform these actions here.
    return { canEdit: false, canDelete: false, canEditPermissions: false };
  };

  // Since UserManagement is only accessible by Admin now, displayedUsers should be all users.
  const displayedUsers = users;


  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-100">Users</h2>
        {loggedInUser.role === 'admin' && (
            <button
            onClick={() => handleOpenUserFormModal()}
            className="bg-primary hover:bg-primary-hover text-white font-semibold py-2 px-4 rounded-lg shadow-md hover:shadow-lg transition duration-150 ease-in-out flex items-center space-x-2"
            >
            <PlusIcon className="h-5 w-5" />
            <span>Add User</span>
            </button>
        )}
      </div>
      
      {displayedUsers.length === 0 ? (
         <p className="text-gray-500 dark:text-gray-400 text-center py-4">No users found.</p>
      ) : (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Avatar</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">ID</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Name</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Team</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Designation</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Role</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            {displayedUsers.map((user) => {
              const permissions = canPerformActionOnUser(user);
              return (
              <tr key={user.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                    <UserAvatar user={user} size="md" />
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{user.id}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">{user.name}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{getTeamName(user.teamId)}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">{user.designation || 'N/A'}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {user.role === 'admin' ? 
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100 capitalize">{user.role}</span> :
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100 capitalize">{user.role}</span>
                    }
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-1">
                  {permissions.canEdit && (
                    <button onClick={() => handleOpenUserFormModal(user)} className="text-primary hover:text-primary-hover p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" aria-label={`Edit user ${user.name}`}>
                        <EditIcon className="h-5 w-5" />
                    </button>
                  )}
                  {permissions.canEditPermissions && (
                     <button 
                        onClick={() => handleOpenPermissionsModal(user)} 
                        className="text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-300 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700" 
                        aria-label={`Edit assignment permissions for ${user.name}`}
                        title="Edit Assignment Permissions"
                    >
                        <ShieldCheckIcon className="h-5 w-5" />
                    </button>
                  )}
                  {permissions.canDelete && (
                    <button 
                        onClick={() => onDeleteUser(user.id)} 
                        className="text-danger hover:text-danger-hover p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed" 
                        aria-label={`Delete user ${user.name}`}
                        disabled={!permissions.canDelete} 
                        title={!permissions.canDelete ? "Cannot delete this user." : "Delete user"}
                    >
                        <TrashIcon className="h-5 w-5" />
                    </button>
                  )}
                </td>
              </tr>
            )})}
          </tbody>
        </table>
      </div>
      )}

      {isUserFormModalOpen && (
        <Modal isOpen={isUserFormModalOpen} onClose={handleCloseUserFormModal} title={editingUser ? 'Edit User' : 'Add User'} size="xl">
          <UserForm
            onSubmit={handleSaveUser}
            initialUser={editingUser}
            teams={teams}
            onClose={handleCloseUserFormModal}
            isEditing={!!editingUser}
            loggedInUser={loggedInUser} 
          />
        </Modal>
      )}

      {isPermissionsModalOpen && userForPermissions && (
        <AssignmentPermissionsModal
            isOpen={isPermissionsModalOpen}
            onClose={handleClosePermissionsModal}
            targetUser={userForPermissions}
            allUsers={allUsers}
            onSavePermissions={handleSavePermissions}
            onResetPermissions={handleResetPermissions}
        />
      )}
    </div>
  );
};

export default UserManagement;