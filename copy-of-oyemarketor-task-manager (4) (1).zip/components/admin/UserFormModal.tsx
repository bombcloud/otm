
import React, { useState, useEffect, useRef } from 'react';
import { User, Team, UserRole } from '../../types';
import UserAvatar from '../UserAvatar'; // For preview

export interface UserFormData {
  id: string; 
  name: string;
  password?: string; 
  teamId: string;
  role: UserRole;
  designation?: string;
  avatarUrl?: string; 
}

interface UserFormProps {
  onSubmit: (userData: UserFormData) => void;
  initialUser?: User | null;
  teams: Team[];
  onClose: () => void;
  isEditing: boolean;
  loggedInUser: User; 
}

const UserForm: React.FC<UserFormProps> = ({ onSubmit, initialUser, teams, onClose, isEditing, loggedInUser }) => {
  const [idState, setIdState] = useState(''); 
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [teamId, setTeamId] = useState<string>('');
  const [role, setRole] = useState<UserRole>('user');
  const [designation, setDesignation] = useState('');
  
  const [avatarPreview, setAvatarPreview] = useState<string | undefined>(initialUser?.avatarUrl);
  const [avatarRemoved, setAvatarRemoved] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isAdminContext = loggedInUser.role === 'admin';

  useEffect(() => {
    if (initialUser) {
      setIdState(initialUser.id); 
      setName(initialUser.name);
      setTeamId(initialUser.teamId);
      setRole(initialUser.role);
      setDesignation(initialUser.designation || '');
      setAvatarPreview(initialUser.avatarUrl);
      setPassword(''); 
      setAvatarRemoved(false);
    } else {
      // Reset for new user
      setIdState('');
      setName('');
      setPassword('');
      setTeamId(teams.length > 0 ? teams[0].id : '');
      setRole('user'); // Default new users to 'user'
      setDesignation('');
      setAvatarPreview(undefined);
      setAvatarRemoved(false);
    }
  }, [initialUser, teams, isEditing]); // Removed loggedInUser, isTeamLeaderContext as it's simplified

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
        setAvatarRemoved(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveAvatar = () => {
    setAvatarPreview(undefined);
    setAvatarRemoved(true);
    if (fileInputRef.current) {
      fileInputRef.current.value = ""; 
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const currentIdFromState = idState.trim();

    if (!currentIdFromState) {
        alert("User ID (username) is required.");
        return;
    }
    if (!name.trim()) {
      alert("User name is required.");
      return;
    }
    if (!isEditing && !password.trim()) { 
      alert("Password is required for new users.");
      return;
    }
    if (!teamId && teams.length > 0) { // Check if teams exist before requiring
      alert("Please assign the user to a team.");
      return;
    }
     if (teams.length === 0 && !teamId) {
       // Allow creating user if no teams exist yet, teamId will be empty
    }


    const formData: UserFormData = { 
        id: currentIdFromState, 
        name, 
        teamId: teamId || '', // Handle case where no teams exist
        role, 
        designation, 
        avatarUrl: avatarRemoved ? '' : avatarPreview 
    };

    if (password.trim()) { 
      formData.password = password;
    } else if (!isEditing) { 
        alert("Password is required for new users.");
        return;
    }
    
    onSubmit(formData);
  };
  
  // Field disabling logic: Only admin can edit sensitive fields of existing users.
  // When adding a new user, all fields are enabled for admin.
  const idFieldDisabled = isEditing && !isAdminContext;
  const teamFieldDisabled = !isAdminContext && isEditing; // User cannot change their own team via this form
  const roleFieldDisabled = !isAdminContext; // User cannot change their own role or others' roles
  const passwordFieldEnabled = isAdminContext || !isEditing; // Admin can always set password, new users require it

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label htmlFor="userIdAdmin" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          User ID (Username) <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="userIdAdmin"
          value={idState}
          onChange={(e) => setIdState(e.target.value)}
          required
          disabled={idFieldDisabled} 
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-50 disabled:bg-gray-200 dark:disabled:bg-gray-600"
        />
      </div>
      
      <div>
        <label htmlFor="userNameAdmin" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Full Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="userNameAdmin"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          disabled={!isAdminContext && isEditing}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
        />
      </div>
      <div>
        <label htmlFor="passwordAdmin" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Password {isEditing && isAdminContext ? '(Leave blank to keep current)' : (!isEditing ? <span className="text-red-500">*</span> : '')}
        </label>
        <input
          type="password"
          id="passwordAdmin"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required={!isEditing} 
          disabled={!passwordFieldEnabled}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-50"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Avatar
        </label>
        <div className="mt-1 flex items-center space-x-4">
          <UserAvatar user={{ ...(initialUser || {id: '', name: 'Preview', teamId: '', role: 'user'}), avatarUrl: avatarPreview }} size="md" />
          <input
            type="file"
            id="adminAvatarFile"
            accept="image/*"
            ref={fileInputRef}
            onChange={handleFileChange}
            disabled={!isAdminContext && isEditing}
            className="block w-full text-sm text-gray-500 dark:text-gray-400
                       file:mr-4 file:py-2 file:px-4
                       file:rounded-full file:border-0
                       file:text-sm file:font-semibold
                       file:bg-primary-hover file:text-primary-text
                       hover:file:bg-primary disabled:opacity-70"
          />
        </div>
        {avatarPreview && (isAdminContext || !isEditing) && (
            <button 
                type="button" 
                onClick={handleRemoveAvatar}
                className="mt-2 text-xs text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
            >
                Remove Avatar
            </button>
        )}
      </div>

      <div>
        <label htmlFor="teamIdAdmin" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Team {teams.length > 0 ? <span className="text-red-500">*</span> : '(No teams exist yet)'}
        </label>
        <select
          id="teamIdAdmin"
          value={teamId}
          onChange={(e) => setTeamId(e.target.value)}
          required={teams.length > 0}
          disabled={teamFieldDisabled || teams.length === 0}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-50"
        >
          <option value="" disabled={teams.length > 0}>Select a team</option>
          {teams.map(team => (
            <option key={team.id} value={team.id}>
              {team.name}
            </option>
          ))}
        </select>
         {teams.length === 0 && <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">No teams available. User will not be assigned to any team.</p>}
      </div>
      <div>
        <label htmlFor="roleAdmin" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Role <span className="text-red-500">*</span>
        </label>
        <select
          id="roleAdmin"
          value={role}
          onChange={(e) => setRole(e.target.value as UserRole)}
          required
          disabled={roleFieldDisabled}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-50"
        >
          <option value="user">User</option>
          { isAdminContext && <option value="admin">Admin</option> }
        </select>
      </div>
      <div>
        <label htmlFor="designationAdmin" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Designation
        </label>
        <input
          type="text"
          id="designationAdmin"
          value={designation}
          onChange={(e) => setDesignation(e.target.value)}
          disabled={!isAdminContext && isEditing}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70"
        />
      </div>
      
      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm transition"
        >
          Cancel
        </button>
        <button
          type="submit"
          disabled={ (teams.length === 0 && !isEditing && !teamId) && false} // Submit should generally be enabled, specific field validations handle issues
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-hover rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isEditing ? 'Save Changes' : 'Create User'}
        </button>
      </div>
    </form>
  );
};

export default UserForm;