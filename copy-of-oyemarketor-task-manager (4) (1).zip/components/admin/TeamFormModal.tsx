import React, { useState, useEffect } from 'react';
import { Team } from '../../types';

export interface TeamFormData {
  name: string;
}

interface TeamFormProps {
  onSubmit: (teamData: TeamFormData) => void;
  initialTeam?: Team | null;
  onClose: () => void;
}

const TeamForm: React.FC<TeamFormProps> = ({ onSubmit, initialTeam, onClose }) => {
  const [name, setName] = useState('');

  useEffect(() => {
    if (initialTeam) {
      setName(initialTeam.name);
    } else {
      setName('');
    }
  }, [initialTeam]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
     if (!name.trim()) {
      alert("Team name is required.");
      return;
    }
    onSubmit({ name });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="teamName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Team Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="teamName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-600 hover:bg-gray-200 dark:hover:bg-gray-500 border border-gray-300 dark:border-gray-500 rounded-md shadow-sm transition"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-hover rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition"
        >
          {initialTeam ? 'Save Changes' : 'Create Team'}
        </button>
      </div>
    </form>
  );
};

export default TeamForm;