
import React from 'react';
import { TaskStatus } from '../types';
import { STATUS_OPTIONS } from '../constants';
import { CheckCircleIcon } from './icons/CheckCircleIcon';
import { ClockIcon } from './icons/ClockIcon';
import { ExclamationTriangleIcon } from './icons/ExclamationTriangleIcon';


interface StatusBadgeProps {
  status: TaskStatus;
}

const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  const statusInfo = STATUS_OPTIONS.find(option => option.value === status);

  if (!statusInfo) {
    return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-gray-200 text-gray-700">Unknown</span>;
  }
  
  const IconComponent = () => {
    switch(status) {
        case TaskStatus.Completed: return <CheckCircleIcon className="h-3 w-3 mr-1"/>;
        case TaskStatus.InProgress: return <ClockIcon className="h-3 w-3 mr-1"/>;
        case TaskStatus.Pending: return <ExclamationTriangleIcon className="h-3 w-3 mr-1"/>;
        default: return null;
    }
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusInfo.color} text-white`}
    >
      <IconComponent/>
      {statusInfo.label}
    </span>
  );
};

export default StatusBadge;
