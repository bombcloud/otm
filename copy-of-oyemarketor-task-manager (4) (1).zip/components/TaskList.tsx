

import React, { useState, useMemo } from 'react';
import { Task, User, TaskStatus } from '../types';
import { STATUS_OPTIONS } from '../constants'; 
import TaskItem from './TaskItem';
import LiveActivityTable from './LiveActivityTable'; 
import { FilterIcon } from './icons/FilterIcon';
import { SortAscendingIcon } from './icons/SortAscendingIcon';
import { SortDescendingIcon } from './icons/SortDescendingIcon';


interface TaskListProps {
  tasks: Task[];
  users: User[]; 
  onEditTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onUpdateTaskStatus: (taskId: string, status: TaskStatus) => void;
  loggedInUser: User; 
}

type SortKey = 'dueDate' | 'createdAt' | 'title';
type SortOrder = 'asc' | 'desc';

export const TaskList: React.FC<TaskListProps> = ({ tasks, users, onEditTask, onDeleteTask, onUpdateTaskStatus, loggedInUser }) => {
  const [filterStatus, setFilterStatus] = useState<TaskStatus | ''>('');
  const [filterAssignee, setFilterAssignee] = useState<string | ''>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [sortKey, setSortKey] = useState<SortKey>('createdAt');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  const availableAssigneesForFilter = useMemo(() => {
    if (loggedInUser.role === 'admin') {
      return users;
    }
    // Regular users only see themselves in the filter dropdown if an assignee filter is shown to them.
    // For simplicity, now only admin sees assignee filter.
    return users.filter(u => u.id === loggedInUser.id);
  }, [users, loggedInUser]);

  const filteredAndSortedTasks = useMemo(() => {
    let visibleTasks: Task[];

    if (loggedInUser.role === 'admin') {
      visibleTasks = [...tasks];
    } else { // 'user' role
      visibleTasks = tasks.filter(task => 
        task.assigneeId === loggedInUser.id || task.creatorId === loggedInUser.id
      );
    }

    let filtered = [...visibleTasks];

    // Filtering logic is primarily for admin view now
    if (loggedInUser.role === 'admin') {
        if (filterStatus) {
        filtered = filtered.filter(task => task.status === filterStatus);
        }
        if (filterAssignee) {
        filtered = filtered.filter(task => task.assigneeId === filterAssignee);
        }
        if (searchTerm) {
        filtered = filtered.filter(task => 
            task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (task.description && task.description.toLowerCase().includes(searchTerm.toLowerCase()))
        );
        }
    }


    filtered.sort((a, b) => {
      let valA, valB;
      if (sortKey === 'dueDate') {
        valA = a.dueDate ? new Date(a.dueDate).getTime() : (sortOrder === 'asc' ? Infinity : -Infinity);
        valB = b.dueDate ? new Date(b.dueDate).getTime() : (sortOrder === 'asc' ? Infinity : -Infinity);
      } else if (sortKey === 'createdAt') {
        valA = new Date(a.createdAt).getTime();
        valB = new Date(b.createdAt).getTime();
      } else { 
        valA = a.title.toLowerCase();
        valB = b.title.toLowerCase();
      }
      
      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [tasks, users, filterStatus, filterAssignee, searchTerm, sortKey, sortOrder, loggedInUser]);

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(prevOrder => prevOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('asc');
    }
  };
  
  const SortIndicator: React.FC<{ currentKey: SortKey, targetKey: SortKey, currentOrder: SortOrder }> = ({ currentKey, targetKey, currentOrder }) => {
    if (currentKey !== targetKey) return null;
    return currentOrder === 'asc' ? <SortAscendingIcon className="w-4 h-4 ml-1" /> : <SortDescendingIcon className="w-4 h-4 ml-1" />;
  };

  const handleUserSelectFromActivityTable = (userId: string) => {
    if (loggedInUser.role === 'admin') {
        setFilterAssignee(userId);
        const filterControls = document.getElementById('filterControls');
        if (filterControls) {
            filterControls.scrollIntoView({ behavior: 'smooth', block: 'start'});
        }
    }
  };

  const canLoggedInUserCreateTasks = loggedInUser.role === 'admin' || (loggedInUser.role === 'user' && loggedInUser.customAssignmentRules);

  if (tasks.length === 0 && loggedInUser.role !== 'admin' && !canLoggedInUserCreateTasks) { 
    return <div className="text-center py-10 text-gray-500 dark:text-gray-400">
        <h2 className="text-2xl font-semibold">No tasks assigned to you or created by you.</h2>
    </div>;
  }
  
  return (
    <div className="space-y-6">
      {loggedInUser.role === 'admin' && (
        <LiveActivityTable 
            users={users} 
            tasks={tasks} 
            onUserSelect={handleUserSelectFromActivityTable} 
        />
      )}

      {loggedInUser.role === 'admin' && ( // Filters and sort only for admin
        <div id="filterControls" className="bg-white dark:bg-gray-800 p-4 sm:p-6 rounded-lg shadow-lg">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6 items-end">
            <div>
              <label htmlFor="searchTerm" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Search Tasks</label>
              <input
                type="text"
                id="searchTerm"
                placeholder="Search by title or description..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
              />
            </div>
            <div>
              <label htmlFor="filterStatus" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center">
                <FilterIcon className="w-4 h-4 mr-1" /> Filter by Status
              </label>
              <select
                id="filterStatus"
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as TaskStatus | '')}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="">All Statuses</option>
                {STATUS_OPTIONS.map(option => (
                  <option key={option.value} value={option.value}>{option.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="filterAssignee" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center">
                <FilterIcon className="w-4 h-4 mr-1" /> Filter by Assignee
              </label>
              <select
                id="filterAssignee"
                value={filterAssignee}
                onChange={(e) => setFilterAssignee(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100"
              >
                <option value="">All Assignees</option>
                {availableAssigneesForFilter.map(user => ( 
                  <option key={user.id} value={user.id}>{user.name} ({user.designation || user.role})</option>
                ))}
              </select>
            </div>
            <div className="flex space-x-2 items-center justify-start md:justify-end pt-4 md:pt-0">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300 mr-2">Sort by:</span>
              <button onClick={() => handleSort('title')} className="px-3 py-2 text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center transition">
                Title <SortIndicator currentKey={sortKey} targetKey="title" currentOrder={sortOrder} />
              </button>
              <button onClick={() => handleSort('dueDate')} className="px-3 py-2 text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center transition">
                Due Date <SortIndicator currentKey={sortKey} targetKey="dueDate" currentOrder={sortOrder} />
              </button>
              <button onClick={() => handleSort('createdAt')} className="px-3 py-2 text-xs sm:text-sm border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center transition">
                Created <SortIndicator currentKey={sortKey} targetKey="createdAt" currentOrder={sortOrder} />
              </button>
            </div>
          </div>
        </div>
      )}
      
      {filteredAndSortedTasks.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAndSortedTasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              assignee={users.find(u => u.id === task.assigneeId)}
              users={users} 
              onEdit={() => onEditTask(task)}
              onDelete={() => onDeleteTask(task.id)}
              onUpdateStatus={(newStatus) => onUpdateTaskStatus(task.id, newStatus)}
              loggedInUser={loggedInUser}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-10 text-gray-500 dark:text-gray-400">
          <h2 className="text-xl font-semibold">
            { tasks.length === 0 && canLoggedInUserCreateTasks && loggedInUser.role === 'admin' ? "No tasks yet. Click 'Add New Task' to create one." : 
              tasks.length === 0 && !canLoggedInUserCreateTasks && loggedInUser.role === 'user' ? "No tasks assigned to you or created by you." :
              "No tasks match your current view or filters."
            }
          </h2>
           { loggedInUser.role === 'admin' && (searchTerm || filterStatus || filterAssignee) && tasks.length > 0 &&
             <p className="mt-1">Try adjusting your search or filter criteria.</p>
          }
        </div>
      )}
    </div>
  );
};
