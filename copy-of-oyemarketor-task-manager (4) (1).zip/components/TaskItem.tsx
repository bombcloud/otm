
import React from 'react';
import { Task, User, TaskStatus } from '../types';
import { STATUS_OPTIONS } from '../constants';
import UserAvatar from './UserAvatar';
import StatusBadge from './StatusBadge';
import { EditIcon } from './icons/EditIcon';
import { TrashIcon } from './icons/TrashIcon';
import { CalendarIcon } from './icons/CalendarIcon';
import { UserIcon } from './icons/UserIcon'; // Generic user icon for labels
import { FingerPrintIcon } from './icons/FingerPrintIcon'; // Icon for "Created By"

interface TaskItemProps {
  task: Task;
  assignee?: User;
  users: User[]; 
  onEdit: () => void;
  onDelete: () => void;
  onUpdateStatus: (newStatus: TaskStatus) => void;
  loggedInUser: User; 
}

const TaskItem: React.FC<TaskItemProps> = ({ task, assignee, users, onEdit, onDelete, onUpdateStatus, loggedInUser }) => {
  const { title, description, status, dueDate, creatorId } = task;

  const creator = users.find(u => u.id === creatorId);

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    onUpdateStatus(e.target.value as TaskStatus);
  };

  const formattedDueDate = dueDate ? new Date(dueDate).toLocaleDateString(undefined, {timeZone: 'UTC'}) : 'No due date';

  const canDeleteTask = () => {
    if (loggedInUser.role === 'admin') return true;
    if (loggedInUser.role === 'user' && creatorId === loggedInUser.id) return true;
    return false; 
  };
  
  const canEditTask = () => {
    if (loggedInUser.role === 'admin') return true;
    if (loggedInUser.role === 'user') {
        // User can edit if they created it or it's assigned to them.
        // Or if they have custom assignment rules (which implies they might be able to re-assign as part of edit)
        if (task.creatorId === loggedInUser.id || task.assigneeId === loggedInUser.id) return true;
        if (loggedInUser.customAssignmentRules) return true; // Allows opening form, detailed checks in TaskForm/App
    }
    return false;
  };

  const canUpdateStatusDirectly = () => {
    if (loggedInUser.role === 'admin') return true;
    if (loggedInUser.role === 'user' && (task.assigneeId === loggedInUser.id || task.creatorId === loggedInUser.id)) return true;
    return false;
  }


  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden flex flex-col">
      <div className="p-6 flex-grow">
        <div className="flex justify-between items-start mb-3">
          <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mr-2 break-words">{title}</h3>
          <div className="flex-shrink-0">
            <StatusBadge status={status} />
          </div>
        </div>

        {description && (
          <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 break-words whitespace-pre-wrap">{description.substring(0,100)}{description.length > 100 ? '...' : ''}</p>
        )}

        <div className="space-y-3 text-sm">
            <div className="flex items-center text-gray-500 dark:text-gray-400">
                <CalendarIcon className="h-5 w-5 mr-2 text-gray-400 dark:text-gray-500" />
                <span>{formattedDueDate}</span>
            </div>
            <div className="flex items-center">
                <UserAvatar user={assignee} size="sm" />
                <span className="ml-2 text-gray-700 dark:text-gray-300">
                  Assigned to: {assignee ? assignee.name : 'Unassigned'}
                </span>
            </div>
             {creator && (
                <div className="flex items-center">
                    <UserAvatar user={creator} size="sm" />
                    <span className="ml-2 text-gray-700 dark:text-gray-300">
                        Created by: {creator.name}
                    </span>
                </div>
            )}
        </div>
      </div>
      
      <div className="border-t border-gray-200 dark:border-gray-700 p-4 bg-gray-50 dark:bg-gray-750">
        <div className="flex justify-between items-center">
          <div className="flex space-x-2">
            {canEditTask() && (
                <button
                onClick={onEdit}
                className="p-2 text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-blue-400 transition rounded-full hover:bg-gray-100 dark:hover:bg-gray-600"
                aria-label="Edit task"
                >
                <EditIcon className="h-5 w-5" />
                </button>
            )}
            {canDeleteTask() && (
              <button
                onClick={onDelete}
                className="p-2 text-gray-600 dark:text-gray-300 hover:text-danger dark:hover:text-red-400 transition rounded-full hover:bg-gray-100 dark:hover:bg-gray-600"
                aria-label="Delete task"
              >
                <TrashIcon className="h-5 w-5" />
              </button>
            )}
          </div>
          <div>
            <select
              value={status}
              onChange={handleStatusChange}
              disabled={!canUpdateStatusDirectly()}
              className="text-xs px-2 py-1 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-primary focus:border-primary dark:bg-gray-700 dark:text-gray-100 disabled:opacity-70 disabled:cursor-not-allowed"
              aria-label="Change task status"
            >
              {STATUS_OPTIONS.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskItem;